function [nodexy,edofMat,Xe,Ye,I,J]=connectivity(nelx,nely,dx,dy)
%% Coordinate and connectivity
nodenrs = reshape(1:(1+nelx)*(1+nely),1+nely,1+nelx);
edofVec = reshape(2*nodenrs(1:end-1,1:end-1)+1,nelx*nely,1);
edofMat = repmat(edofVec,1,8)+repmat([0 1 2*nely+[2 3 0 1] -2 -1],nelx*nely,1);
nodexy=zeros((1+nelx)*(1+nely),2);
for wj=1:nely+1
    for wi=1:nelx+1
        e=wj+(wi-1)*(nely+1);
        nodexy(e,:)=[(wi-1)*dx -(wj-1)*dy];
    end
end
%% Coordinate of central elements
xx=reshape(nodexy(:,1),nely+1,nelx+1);
yy=reshape(nodexy(:,2),nely+1,nelx+1);
xxmat=0.25*(xx(1:end-1,1:end-1)+xx(2:end,1:end-1)+xx(1:end-1,2:end)+xx(2:end,2:end));
yymat=0.25*(yy(1:end-1,1:end-1)+yy(2:end,1:end-1)+yy(1:end-1,2:end)+yy(2:end,2:end));
Xe=xxmat(:);
Ye=yymat(:);
%% Prepare for FEM
ndof=2*(nelx+1)*(nely+1);     %number of degree of freedoms
F=sparse(ndof,1);       % load vector
U=zeros(ndof,1);        % displaement vector
%% Stiffness matrix ans mass matrix
ntriplet=nelx*nely*64;
I=zeros(ntriplet,1);
J=zeros(ntriplet,1);
ntriplet=0;
for wj=1:nely
    for wi=1:nelx
        edof=edofMat(wj+(wi-1)*nely,:);
        for ej=1:8
            for ei=1:8
                ntriplet=ntriplet+1;
                I(ntriplet)=edof(ej);
                J(ntriplet)=edof(ei);
            end
        end
    end
end

