clear all
close all
%% Authors
%Van-Nam Hoang, Phuong Tran, Van-Tuyen Vu, H. Nguyen-Xuan, Design of lattice structures with direct multiscale topology optimization
%,Composite Structures, 252, 112718, 2020 https://www.sciencedirect.com/science/article/pii/S0263822320326441
%% Input data
sc=2;
Lx=120;     Ly=60;  
nelx=120*sc;   nely=60*sc; 
dx=Lx/nelx; dy=Ly/nely;
nel=nelx*nely;      
volfrac=0.5; 
r0=0.9;       rmin=0.5;    rmax=1.25;      % initial thickness, lower bound and upper bound for thickness 
rk=5.5;       rkmin=2;   rkmax=Ly/5;
%% Material properties
E0=1;       % elastic modulus of coating layer 
Emin=1e-4;
nu=0.3;
p=1;
%% Large number
alp=2; 
loop =0; iter=0;
%% Initial Mask 
[XC1,YC1,RC1,XC2,YC2,RC2,nc1,nc2,ld,gam]=mask_initial(Lx,Ly,r0,rk);
% load maskra2
% mask=maskra2;
% RC1=mask(1:nc1/2);
%     XXC=mask(1+nc1/2:nc2/2+nc1/2);
%     YYC=mask([1+nc1/2:nc2/2+nc1/2]+nc2);
%     XC2=[XXC;XXC];
%     YC2=[YYC;-Ly-YYC];
%     RC2=mask(2*nc2+1+nc1/2:2*nc2+nc2/2+nc1/2);      
plot_layout_component(Lx,Ly,XC1,YC1,RC1,XC2,YC2,RC2,nc1,nc2)
%% Coordinate, connectivity, central coordinate of elements in design domain
[nodexy,edofMat,Xe,Ye,I,J]=connectivity(nelx,nely,dx,dy);
[DE]=de_micro(Xe,Ye,XC1,YC1,RC1,nel,nc1);
%% density
[x,sens]=density(nelx,nely,Xe,Ye,XC1,YC1,RC1,XC2,YC2,RC2,nc1,nc2,nel,alp,DE);
%% Element stiffness
[ke]=kemefe(nelx,nely,E0,nu,nodexy);
mask=[RC1;XC2;YC2;RC2];    % design variables
%% START ITERATION 
    m=1;             % number of general constraints
    n=length(mask);  % number of variables x_j
    [xmin,xmax]=xmin_max(Lx,Ly,nc1,nc2,rmax,rmin,rkmin,rkmax);
    maskb=(mask-xmin)./(xmax-xmin);
    xminb=zeros(n,1);
    xmaxb=ones(n,1);
    xold1=maskb; 
    xold2=maskb; 
    low=ones(n,1);
    upp=ones(n,1);
    a0=1;
    a=zeros(m,1);
    c_mma=1e3*ones(m,1);    
    d=zeros(m,1);
    %-------------
dc=zeros(nely,nelx); dc=zeros(nely,nelx); 
change=1;
Vol=zeros(150,1);
alctr=0.993;
while change >1e-9 & loop<120
loop=loop+1;
alp=min(2+loop*(4.5-2)/80,4.5);
alctr=min(0.973+loop*0.023/100,0.999);
%% Filter
% if ~mod(loop,10) & loop<41 % filtering
%     [XC2,YC2,RC2,nc2,maskb,xmaxb,xminb,xmin,xmax,xold1,xold2,low,upp,n,m,a,c_mma,d]=filtering2(Lx,Ly,XC1,YC1,RC1, XC2,YC2,RC2,nc1,nc2,rkmin,rkmax,rmax,rmin,DC,c_mma); % normailize
%     iter=1;
% else
%     iter=iter+1;
% end
[x,sens]=density(nelx,nely,Xe,Ye,XC1,YC1,RC1,XC2,YC2,RC2,nc1,nc2,nel,alp,DE);
xold=maskb;
%% FEM and sensitivity analysis 
[U]=FEM(nelx,nely,edofMat,ke,Emin,x,I,J,p);
%% Sensitivites
c=0;
for wj=1:nely
    for wi=1:nelx
        edof=edofMat(wj+(wi-1)*nely,:);
        Ue=U(edof);
        dc(wj,wi)=-(1-Emin)*x(wj,wi)^(p-1)*p*Ue'*ke*Ue;
        c=c+(Emin+(1-Emin)*x(wj,wi)^p)*Ue'*ke*Ue;
    end
end

% DC=dc(:)'*sens(:,1+2*nc1:end);     % sensitivity
% DV=sum(sens(:,1+2*nc1:end))/(nel*volfrac);
DC=dc(:)'*sens;     % sensitivity
DV=sum(sens)/(nel*volfrac);
DC=DC'.*(xmax-xmin); % normalization of design vatiables
DV=DV'.*(xmax-xmin);
%%
C(loop)=c;          % history of objective
Vol(loop)=mean(x(:));  % history of volume fraction
%% Check sensitivites
% [DDC]=FDM_sensitivity(nelx,nely,Xe,Ye,edofMat,ke,nel,Emin,I,J,mask,nc1,nc2,alp,c);
% DC1=dc(:)'*sens;
% par=3;
% par2=2;
% dd=DC1(1+par*nc1+par2*nc2:10+par*nc1+par2*nc2)./DDC(1+par*nc1+par2*nc2:10+par*nc1+par2*nc2)
%% DESIGN UPDATE BY THE OPTIMALITY CRITERIA METHOD 
%     iter=iter+1;        % current iteration number 
    xval=maskb; 
    f0val=c;
    df0dx=DC;
    df0dx2=0*df0dx;
    fval=sum(x(:))/(nel*volfrac)-1; 
    dfdx=DV;
    dfdx2=0*dfdx; 
%     fval=[sum(x(:))/(nel*volfrac)-1;Pdist-0.05]; 
%     dfdx=[DV';dPdist'];
%     dfdx2=0*dfdx; 
    [xmma,ymma,zmma,lam,xsi,eta,mu,zet,s,low,upp] = mmasub(m,n,iter,xval,xminb,xmaxb,xold1,xold2,f0val,df0dx,df0dx2,fval,dfdx,dfdx2,low,upp,a0,a,c_mma,d,alctr);
    maskb=xmma;
    mask=maskb.*(xmax-xmin)+xmin;
% 
%     RC1=mask(1:nc1/2);  
%     XC2=mask(1+nc1/2:nc2+nc1/2);  
%     YC2=mask(1+nc2+nc1/2:2*nc2+nc1/2);
%     RC2=mask(1+2*nc2+nc1/2:end);
%%sym
    RC1=mask(1:nc1/2);
    XXC=mask(1+nc1/2:nc2/2+nc1/2);
    YYC=mask([1+nc1/2:nc2/2+nc1/2]+nc2);
    XC2=[XXC;XXC];
    YC2=[YYC;-Ly-YYC];
    RC2=mask(2*nc2+1+nc1/2:2*nc2+nc2/2+nc1/2);      RC2(end/2+1:end)=RC2(1:end/2); 

%%
    xold2=xold1;
    xold1=maskb; %x(:);
    change = max(max(abs(maskb-xold)));  
figure(1)
axis([0 Lx -Ly 0]); axis equal
% colormap(gray); 
imagesc(x); axis equal; axis off;pause(1e-6);
disp([' It.: ' sprintf('%4i',loop) ' Obj.: ' sprintf('%10.4f',full(c)) ...
       ' Vol.: ' sprintf('%6.3f',Vol(loop,:)) ' ch.: ' sprintf('%6.3f',change) ' maxRC2.: ' sprintf('%6.3f',max(RC2))]) 
   %%
% if ~mod(loop,20) & loop<110 % filtering
% pause
% end
end 
close 2 
plot_layout_component(Lx,Ly,XC1,YC1,RC1,XC2,YC2,RC2,nc1,nc2)
figure(3)
plot(C,'k-','linewidth',1.5)
xlabel('Iteration')
ylabel('Objective')
axis([0 loop 0 200]);
figure(4)
plot(Vol,'linewidth',1.5)
xlabel('Iteration')
ylabel('Vol')
axis([0 loop 0 1]);
%%%%%%%%%%%%%%
  colormap(white);
%   filter = fspecial('gaussian', [3 3], 0.5);
      filter = fspecial('disk',0.9);
%       filter = fspecial('average',[3 3]); 
                      xPhys = filter2(filter,x); 
    value = findContourValueWithVolumeFraction(xPhys,volfrac);
    plotContour(xPhys,value,figure(7))
%  caxis([0 1]);   imagesc(1-xPhys);
    axis equal; axis tight; axis off; drawnow;



