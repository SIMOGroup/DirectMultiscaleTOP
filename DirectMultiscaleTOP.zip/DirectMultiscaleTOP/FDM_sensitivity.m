function [DDC]=FDM_sensitivity(nelx,nely,Xe,Ye,edofMat,ke,nel,Emin,I,J,mask,nc1,nc2,alp,c0)
c0=c0
DDC=zeros(1,3*nc1+5*nc2/2);
ep=1e-4;
for e=1+3*nc1+2*nc2:10+3*nc1+2*nc2
    mask(e)=mask(e)+ep;
    XC1=mask(1:nc1);
    YC1=mask(1+nc1:2*nc1);
    RC1=mask(1+2*nc1:3*nc1);     
    XC2=mask(1+3*nc1:nc2+3*nc1);  
    YC2=mask(1+nc2+3*nc1:2*nc2+3*nc1);
    RC2=mask(1+2*nc2+3*nc1:end);
    [x,sens]=density(nelx,nely,Xe,Ye,XC1,YC1,RC1,XC2,YC2,RC2,nc1,nc2,nel,alp);
    [U]=FEM(nelx,nely,edofMat,ke,Emin,x,I,J);
    c=0;
    for wj=1:nely
        for wi=1:nelx
            edof=edofMat(wj+(wi-1)*nely,:);
            Ue=U(edof);
            c=c+(Emin+(1-Emin)*x(wj,wi)^3)*Ue'*ke*Ue;
        end
    end
    c
    DDC(e)=(c-c0)/ep;
    %----------
    mask(e)=mask(e)-ep;
end
end


