function [DE]=de_micro(Xe,Ye,XC1,YC1,RC1,nel,nc1)
xxc=XC1(2:2:end)-XC1(1:2:end);
yyc=YC1(2:2:end)-YC1(1:2:end);
le=sqrt((XC1(2:2:end)-XC1(1:2:end)).^2+(YC1(2:2:end)-YC1(1:2:end)).^2);     % component length
p=xxc./le;      % cosine
q=yyc./le;      % sine
% Local coordinate
xi=p.*XC1(1:2:end)+q.*YC1(1:2:end);   % xi bar
yi=-q.*XC1(1:2:end)+p.*YC1(1:2:end);
xj=p.*XC1(2:2:end)+q.*YC1(2:2:end);
yj=-q.*XC1(2:2:end)+p.*YC1(2:2:end);
DE=zeros(nel,nc1/2);
for wj=1:nc1/2
    xe=p(wj)*Xe+q(wj)*Ye;        
    ye=-q(wj)*Xe+p(wj)*Ye;
    yiye=yi(wj)-ye;
    de=abs(yiye);
    edof_left=find(xe<xi(wj));
    edof_right=find(xe>xj(wj));
    if length(edof_left)>0
        de(edof_left)=sqrt((xi(wj)-xe(edof_left)).^2+(yi(wj)-ye(edof_left)).^2);
    else
    end
    if length(edof_right)>0
        de(edof_right)=sqrt((xj(wj)-xe(edof_right)).^2+(yj(wj)-ye(edof_right)).^2);
    else
    end
    DE(:,wj)=de;
end



