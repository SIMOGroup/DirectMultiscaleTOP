clear all
ZC=[0,10,10,2];
YC=[10,0,0,10];
alp=10;
t=2;
Z=[7]; Y=7;
dij1=sqrt((ZC(1)-ZC(2))^2+(YC(1)-YC(2))^2);
de1=abs(det([ZC(1)-Z(1) YC(1)-Y(1);
            ZC(2)-Z(1) YC(2)-Y(1)]))/dij1;
dij2=sqrt((ZC(3)-ZC(4))^2+(YC(3)-YC(4))^2);
de2=abs(det([ZC(3)-Z(1) YC(3)-Y(1);
            ZC(4)-Z(1) YC(4)-Y(1)]))/dij2;
        de=[de1,de2];
X=prod(1./(1+exp(-alp*(de-t))));

dXdx(1)=alp*exp(-alp*(de(1)-t))*X*(1/(1+exp(-alp*(de(1)-t))))*(((YC(2)-Y(1))*dij1^2+abs(det([ZC(1)-Z(1) YC(1)-Y(1);ZC(2)-Z(1) YC(2)-Y(1)]))*(ZC(2)-ZC(1)))/dij1^3);
dXdx(2)=alp*exp(-alp*(de(1)-t))*X*(1/(1+exp(-alp*(de(1)-t))))*((-(YC(1)-Y(1))*dij1^2-abs(det([ZC(1)-Z(1) YC(1)-Y(1);ZC(2)-Z(1) YC(2)-Y(1)]))*(ZC(2)-ZC(1)))/dij1^3);
dXdx(3)=alp*exp(-alp*(de(2)-t))*X*(1/(1+exp(-alp*(de(2)-t))))*((-(YC(4)-Y(1))*dij2^2+abs(det([ZC(3)-Z(1) YC(3)-Y(1);ZC(4)-Z(1) YC(4)-Y(1)]))*(ZC(4)-ZC(3)))/dij2^3);
dXdx(4)=alp*exp(-alp*(de(2)-t))*X*(1/(1+exp(-alp*(de(2)-t))))*(((YC(3)-Y(1))*dij2^2-abs(det([ZC(3)-Z(1) YC(3)-Y(1);ZC(4)-Z(1) YC(4)-Y(1)]))*(ZC(4)-ZC(3)))/dij2^3);
ep=1e-11;
for wj=1:4
    ZC(wj)=ZC(wj)+ep;
    ddij1=sqrt((ZC(1)-ZC(2))^2+(YC(1)-YC(2))^2);
    dde1=abs(det([ZC(1)-Z(1) YC(1)-Y(1);
            ZC(2)-Z(1) YC(2)-Y(1)]))/ddij1;
    ddij2=sqrt((ZC(3)-ZC(4))^2+(YC(3)-YC(4))^2);
    dde2=abs(det([ZC(3)-Z(1) YC(3)-Y(1);
            ZC(4)-Z(1) YC(4)-Y(1)]))/ddij2;
    dde=[dde1,dde2];
    XX=prod(1./(1+exp(-alp*(dde-t))));
    DC(wj)=(XX-X)/ep;
    ZC(wj)=ZC(wj)-ep;
end
dd=dXdx./DC;
aa=1;