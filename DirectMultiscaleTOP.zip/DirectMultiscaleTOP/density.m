function [x,sens]=density(nelx,nely,Xe,Ye,XC1,YC1,RC1,XC2,YC2,RC2,nc1,nc2,nel,alp,DE)
%% Micro
pai1=zeros(nel,nc1/2);
dPHI1=zeros(nel,nc1/2+5*nc2/2);
for wj=1:nc1/2
    de=DE(:,wj);
    phi1=1./(1+exp(-alp*(de-RC1(wj))));
    pai1(:,wj)=phi1;
    dphi1dek=alp.*exp(-alp*(de-RC1(wj))).*phi1;
    dPHI1(:,wj)=-dphi1dek;
end
PHI1=prod(pai1,2); % PAI2
dPHI1=PHI1.*dPHI1;
%% Macro
xxc=XC2(2:2:end)-XC2(1:2:end);
yyc=YC2(2:2:end)-YC2(1:2:end);
le=sqrt((XC2(2:2:end)-XC2(1:2:end)).^2+(YC2(2:2:end)-YC2(1:2:end)).^2);     % component length
p=xxc./le;      % cosine
q=yyc./le;      % sine
% Local coordinate
xi=p.*XC2(1:2:end)+q.*YC2(1:2:end);   % xi bar
yi=-q.*XC2(1:2:end)+p.*YC2(1:2:end);
xj=p.*XC2(2:2:end)+q.*YC2(2:2:end);
yj=-q.*XC2(2:2:end)+p.*YC2(2:2:end);
%
pai2=zeros(nel,nc2/2);
dPHI2=zeros(nel,nc1/2+5*nc2/2);
for wj=1:nc2/2
    % derivative of p, q with respect to Xi,Yi,Xj,Yj (end points)
    dpdXi=(-le(wj)^2+(XC2(2*wj)-XC2(2*wj-1))*(XC2(2*wj)-XC2(2*wj-1)))/le(wj)^3;
    dpdYi=(XC2(2*wj)-XC2(2*wj-1))*(YC2(2*wj)-YC2(2*wj-1))/le(wj)^3;
    dpdXj=-dpdXi;
    dpdYj=-dpdYi;
    dqdXi=(YC2(2*wj)-YC2(2*wj-1))*(XC2(2*wj)-XC2(2*wj-1))/le(wj)^3;
    dqdYi=(-le(wj)^2+(YC2(2*wj)-YC2(2*wj-1))*(YC2(2*wj)-YC2(2*wj-1)))/le(wj)^3;
    dqdXj=-dqdXi;
    dqdYj=-dqdYi;
    % derivative of local coordinate xi,yi,xj,yj with respect to Xi,Yi,Xj,Yj
    dxidXi=p(wj)+XC2(2*wj-1)*dpdXi+YC2(2*wj-1)*dqdXi;
    dxidYi=q(wj)+XC2(2*wj-1)*dpdYi+YC2(2*wj-1)*dqdYi;
    dxidXj=      XC2(2*wj-1)*dpdXj+YC2(2*wj-1)*dqdXj;
    dxidYj=      XC2(2*wj-1)*dpdYj+YC2(2*wj-1)*dqdYj;
    %---------------------------------------------
    dyidXi=-q(wj)-XC2(2*wj-1)*dqdXi+YC2(2*wj-1)*dpdXi;
    dyidYi= p(wj)-XC2(2*wj-1)*dqdYi+YC2(2*wj-1)*dpdYi;
    dyidXj=      -XC2(2*wj-1)*dqdXj+YC2(2*wj-1)*dpdXj;
    dyidYj=      -XC2(2*wj-1)*dqdYj+YC2(2*wj-1)*dpdYj;
    %---------------------------------------------
    dxjdXi=      XC2(2*wj)*dpdXi+YC2(2*wj)*dqdXi;
    dxjdYi=      XC2(2*wj)*dpdYi+YC2(2*wj)*dqdYi;
    dxjdXj=p(wj)+XC2(2*wj)*dpdXj+YC2(2*wj)*dqdXj;
    dxjdYj=q(wj)+XC2(2*wj)*dpdYj+YC2(2*wj)*dqdYj;
    %---------------------------------------------
    dyjdXi=      -XC2(2*wj)*dqdXi+YC2(2*wj)*dpdXi;
    dyjdYi=      -XC2(2*wj)*dqdYi+YC2(2*wj)*dpdYi;
    dyjdXj=-q(wj)-XC2(2*wj)*dqdXj+YC2(2*wj)*dpdXj;
    dyjdYj= p(wj)-XC2(2*wj)*dqdYj+YC2(2*wj)*dpdYj;
    %
    xe=p(wj)*Xe+q(wj)*Ye;         % element coordinate xe in local coordinate systems
    ye=-q(wj)*Xe+p(wj)*Ye;
    dxedXi=Xe*dpdXi+Ye*dqdXi;     % derivative of xe with respect to Xi,Yi,Xj,Yj
    dxedYi=Xe*dpdYi+Ye*dqdYi;
    dxedXj=Xe*dpdXj+Ye*dqdXj;
    dxedYj=Xe*dpdYj+Ye*dqdYj;
    %
    dyedXi=-Xe*dqdXi+Ye*dpdXi;     % derivative of ye with respect to Xi,Yi,Xj,Yj
    dyedYi=-Xe*dqdYi+Ye*dpdYi;
    dyedXj=-Xe*dqdXj+Ye*dpdXj;
    dyedYj=-Xe*dqdYj+Ye*dpdYj;
    %
    yiye=yi(wj)-ye;
    de=abs(yiye);
    dedXi=sign(yiye).*(dyidXi-dyedXi);
    dedYi=sign(yiye).*(dyidYi-dyedYi);
    dedXj=sign(yiye).*(dyidXj-dyedXj);
    dedYj=sign(yiye).*(dyidYj-dyedYj);
    edof_left=find(xe<xi(wj));
    edof_right=find(xe>xj(wj));
    if length(edof_left)>0
        de(edof_left)=sqrt((xi(wj)-xe(edof_left)).^2+(yi(wj)-ye(edof_left)).^2);
        dedxib1=(xi(wj)-xe(edof_left))./de(edof_left);
        dedyib1=(yi(wj)-ye(edof_left))./de(edof_left);
        dedxeb1=-(xi(wj)-xe(edof_left))./de(edof_left);
        dedyeb1=-(yi(wj)-ye(edof_left))./de(edof_left);
        dedXi(edof_left)=dedxib1*dxidXi+dedyib1*dyidXi+dedxeb1.*dxedXi(edof_left)+dedyeb1.*dyedXi(edof_left);
        dedYi(edof_left)=dedxib1*dxidYi+dedyib1*dyidYi+dedxeb1.*dxedYi(edof_left)+dedyeb1.*dyedYi(edof_left);
        dedXj(edof_left)=dedxib1*dxidXj+dedyib1*dyidXj+dedxeb1.*dxedXj(edof_left)+dedyeb1.*dyedXj(edof_left);
        dedYj(edof_left)=dedxib1*dxidYj+dedyib1*dyidYj+dedxeb1.*dxedYj(edof_left)+dedyeb1.*dyedYj(edof_left);
    else
    end
    if length(edof_right)>0
        de(edof_right)=sqrt((xj(wj)-xe(edof_right)).^2+(yj(wj)-ye(edof_right)).^2);
        dedxib2=(xj(wj)-xe(edof_right))./de(edof_right);
        dedyib2=(yj(wj)-ye(edof_right))./de(edof_right);
        dedxeb2=-(xj(wj)-xe(edof_right))./de(edof_right);
        dedyeb2=-(yj(wj)-ye(edof_right))./de(edof_right);
        dedXi(edof_right)=dedxib2*dxjdXi+dedyib2*dyjdXi+dedxeb2.*dxedXi(edof_right)+dedyeb2.*dyedXi(edof_right);
        dedYi(edof_right)=dedxib2*dxjdYi+dedyib2*dyjdYi+dedxeb2.*dxedYi(edof_right)+dedyeb2.*dyedYi(edof_right);
        dedXj(edof_right)=dedxib2*dxjdXj+dedyib2*dyjdXj+dedxeb2.*dxedXj(edof_right)+dedyeb2.*dyedXj(edof_right);
        dedYj(edof_right)=dedxib2*dxjdYj+dedyib2*dyjdYj+dedxeb2.*dxedYj(edof_right)+dedyeb2.*dyedYj(edof_right);
    else
    end
    phi2=1./(1+exp(-alp*(de-RC2(wj))));
    pai2(:,wj)=phi2;
    %%
    dphi2dek=alp.*exp(-alp*(de-RC2(wj))).*phi2;
    dPHI2(:,2*wj-1+nc1/2)=dphi2dek.*dedXi;
    dPHI2(:,2*wj-1+nc2+nc1/2)=dphi2dek.*dedYi;
    dPHI2(:,2*wj+nc1/2)=dphi2dek.*dedXj;
    dPHI2(:,2*wj+nc2+nc1/2)=dphi2dek.*dedYj;
    dPHI2(:,wj+2*nc2+nc1/2)=-dphi2dek;
end
% %
PHI2=prod(pai2,2); % PAI2
dPHI2=PHI2.*dPHI2;
%% Element density and sensitivities
X=(1-PHI1).*(1-PHI2);
x=reshape(X,nely,nelx);
sens=-dPHI1.*(1-PHI2)-dPHI2.*(1-PHI1);


