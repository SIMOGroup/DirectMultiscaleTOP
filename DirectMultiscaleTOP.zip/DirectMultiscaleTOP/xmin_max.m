function [xmin,xmax]=xmin_max(Lx,Ly,nc1,nc2,rmax,rmin,rkmin,rkmax)
db=-5;   % distance form boundary of design domain
%% Micro
Rmin1=rmin*ones(nc1/2,1);
Rmax1=rmax*ones(nc1/2,1);
%% Macro
Zmin2=0*ones(nc2,1)+1*db;
Zmax2=Lx*ones(nc2,1)-1*db;
Ymin2=-Ly*ones(nc2,1)+1*db;
Ymax2=-0.*Ly*ones(nc2,1)-1*db;
Rmin2=rkmin*ones(nc2/2,1);
Rmax2=rkmax*ones(nc2/2,1);
%%
xmin=[Rmin1; Zmin2; Ymin2; Rmin2];
xmax=[Rmax1; Zmax2; Ymax2; Rmax2];
end

