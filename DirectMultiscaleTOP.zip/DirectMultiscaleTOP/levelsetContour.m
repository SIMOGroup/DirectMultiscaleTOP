function area = levelsetContour(bufferedField,value)
% For a given level-set value, compute the area enclosed
% It is assumed that the field has been buffered; see code above
cntr = contours(bufferedField,[value value]);
indices = find(cntr(1,:) == value);
area = 0;
for i = 1:numel(indices)
    startCol = indices(i)+1;
    endCol = startCol+ cntr(2,indices(i))-1;
    xPoly = cntr(1,startCol:endCol);
    yPoly = cntr(2,startCol:endCol);
    area = area + polyarea(xPoly,yPoly);
end