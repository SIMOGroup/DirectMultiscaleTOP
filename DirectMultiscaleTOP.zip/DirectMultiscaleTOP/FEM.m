function [U]=FEM(nelx,nely,edofMat,ke,Emin,x,I,J,p)
ndof=2*(nelx+1)*(nely+1);     %number of degree of freedoms
F=sparse(ndof,1);       % load vector
U=zeros(ndof,1);        % displaement vector
%% Stiffness matrix ans mass matrix
ntriplet=nelx*nely*64;
% I=zeros(ntriplet,1);
% J=zeros(ntriplet,1);
X=zeros(ntriplet,1);
ntriplet=0;
for wj=1:nely
    for wi=1:nelx
        edof=edofMat(wj+(wi-1)*nely,:);
        for ej=1:8
            for ei=1:8
                ntriplet=ntriplet+1;
%                 I(ntriplet)=edof(ej);
%                 J(ntriplet)=edof(ei);
                X(ntriplet)=(Emin+(1-Emin)*x(wj,wi)^p)*ke(ej,ei); %linear
            end
        end
    end
end
K=sparse(I,J,X,ndof,ndof); K=0.5*(K+K');
%MBB
% fixeddofs = union([1:2:2*(nely+1)],[2*(nelx+1)*(nely+1)]);  %MBB
% F(2,1) = -1; % center point
%% Cantilver beam
% F((nely+1)*(nelx+1)*2,1) =-1; % bottom point
F((nely+1)*nelx*2+nely+2,1) = -1; % center point
fixeddofs = 1:2*(nely+1);
%% Simply supported beam
% fixeddofs = [(nely+1)*2-1,(nely+1)*2,2*(nelx+1)*(nely+1)];
% fixeddofs = union([1:2:2*(nely+1)],[2*(nelx+1)*(nely+1)]);  %sym
% F((nely+1)*2,1) = -1; % center point

alldofs = 1:2*(nely+1)*(nelx+1);
freedofs = setdiff(alldofs,fixeddofs);
U(freedofs) = K(freedofs,freedofs) \ F(freedofs);




