function [XC1,YC1,RC1,XC2,YC2,RC2,nc1,nc2,ld,gam]=mask_initial(Lx,Ly,r0,rk)
%% Micro scale
db=0; % distance from boundary of design domain
Nx=21;   Dx=(Lx-2*db)/Nx;
Ny=6;    Dy=(Ly-2*db)/Ny;
nc1=12*Nx*Ny+2*Nx+2*Ny;     % number of end points
XC1=zeros(nc1,1);
YC1=zeros(nc1,1);
for wj=1:Ny
    for wi=1:Nx
        e=wj+(wi-1)*Ny;
        XC1([1:12]+12*(e-1))=[0  0.5 0.5 1 0.5 1 0 0.5 0 1 -0.5   0.5]*Dx+(wi-1)*Dx;
        YC1([1:12]+12*(e-1))=-[0 0.5 0.5 0 0.5 1 1 0.5 0 0 0.5 0.5]*Dy-(wj-1)*Dy;
    end
end
XC1([1:2:2*Nx]+12*Nx*Ny)=[0:Nx-1]*Dx;
XC1([2:2:2*Nx]+12*Nx*Ny)=[1:Nx]*Dx;
YC1([1:2*Nx]+12*Nx*Ny)=-Ny*Dy;
XC1([1:2:2*Ny]+12*Nx*Ny+2*Nx)=(Nx-0.5)*Dx;
XC1([2:2:2*Ny]+12*Nx*Ny+2*Nx)=(Nx+0.5)*Dx;
YC1([1:2:2*Ny]+12*Nx*Ny+2*Nx)=-[0:Ny-1]*Dy-0.5*Dy;
YC1([2:2:2*Ny]+12*Nx*Ny+2*Nx)=-[1:Ny]*Dy+0.5*Dy;
nc1=length(XC1);
RC1=r0*ones(nc1/2,1);
ld=Dx;
gam=atan(Dy/Dx)*180/3.1416;
%% For bars 
% db=5; % distance from boundary of design domain
% Nx=2; nex=1;  Dx=(Lx-2*db)/Nx; 
% Ny=1; ney=1;  Dy=(Ly-2*db)/Ny;
% nc2=nex*Nx*(Ny+1)+ney*Ny*(Nx+1);     % number of end points
% XC2=zeros(nc2,1);
% YC2=zeros(nc2,1);
% zzc=linspace(db,Lx-db,nex*Nx+1);
% yyc=-linspace(db,Ly-db,ney*Ny+1);
% for wj=1:Ny+1
% XC2([1:2:2*nex*Nx]+(wj-1)*2*nex*Nx)=zzc(1:end-1);
% XC2([2:2:2*nex*Nx]+(wj-1)*2*nex*Nx)=zzc(2:end);
% YC2([1:2*nex*Nx]+(wj-1)*2*nex*Nx)=(wj-1)*Dy+(-Ly+db);
% end
% for wi=1:Nx+1
% XC2([1:2*ney*Ny]+(wi-1)*2*ney*Ny+2*nex*Nx*(Ny+1))=(wi-1)*Dx+db;
% YC2([1:2:2*ney*Ny]+(wi-1)*2*ney*Ny+2*nex*Nx*(Ny+1))=yyc(1:end-1);
% YC2([2:2:2*ney*Ny]+(wi-1)*2*ney*Ny+2*nex*Nx*(Ny+1))=yyc(2:end);
% end
% nc2=length(XC2);
% RC2=rk*ones(nc2/2,1);
%% sym
db=5;
gama=2;
Nx=3; nex=2;  Dx=(Lx-2*db)/Nx; % at lease ney >=2
Ny=3; ney=2;  Dy=(Ly-gama*db)/Ny;
nc2=nex*Nx*(Ny+1)+ney*Ny*(Nx+1);
XC2=zeros(nc2,1);
YC2=zeros(nc2,1);
zzc=linspace(db,Lx-db,nex*Nx+1);
yyc=-linspace(0.5*Ly,Ly-0.5*gama*db,ney*Ny/2+1);
for wj=1:floor(Ny/2+1)
XC2([1:2:2*nex*Nx]+(wj-1)*2*nex*Nx)=zzc(1:end-1);
XC2([2:2:2*nex*Nx]+(wj-1)*2*nex*Nx)=zzc(2:end);
YC2([1:2*nex*Nx]+(wj-1)*2*nex*Nx)=(wj-1)*Dy+(-Ly+0.5*gama*db);
end
for wi=1:Nx+1
XC2([1:2*ney*Ny/2]+(wi-1)*2*ney*Ny/2+nex*Nx*(Ny+1))=(wi-1)*Dx+db;
YC2([1:2:2*ney*Ny/2]+(wi-1)*2*ney*Ny/2+nex*Nx*(Ny+1))=yyc(1:end-1);
YC2([2:2:2*ney*Ny/2]+(wi-1)*2*ney*Ny/2+nex*Nx*(Ny+1))=yyc(2:end);
end
XC2=[XC2;XC2];
YC2=[YC2;-Ly-YC2];
nc2=length(XC2);
RC2=rk*ones(nc2/2,1);
