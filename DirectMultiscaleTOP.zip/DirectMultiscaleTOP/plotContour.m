function plotContour(xPhys,value,fig)
%Use Matlab's built-in contour command to draw the optimal topology.
[nely,nelx] = size(xPhys);
figure(fig);
clf;
fill([1 nelx nelx 1],[1 1 nely nely],'y'); 
hold on;
cntr =contourf(-xPhys(end:-1:1,:),[-value -value]); % the second argument is essential
axis('equal'); 
axis tight;
axis off;