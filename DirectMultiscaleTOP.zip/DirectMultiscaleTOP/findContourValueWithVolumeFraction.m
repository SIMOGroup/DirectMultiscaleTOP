function value = findContourValueWithVolumeFraction(field,volfrac)
 % Find the level-set value such that the contour has given vol fraction
 % The code computes the level-set value with desired external volume
[nely,nelx] = size(field);
externalVolumeDesired = nelx*nely*(1-volfrac);
field = -field; % reverse the sign to compute external volume
valMax = 0; valMin =min(field(:));
bufferedField = valMin*ones(nely+2,nelx+2);
% Add buffer to get closed contours
bufferedField(2:end-1,2:end-1) = field;
iterMax = 300;iter = 1;
while (1) % A binary search is used to find the optimal level-set value
    valMid = (valMax+valMin)/2;
    extVol = levelsetContour(bufferedField,valMid);
    err = abs(extVol-externalVolumeDesired)/(extVol);
    if (err < 0.001) || (iter > iterMax);
        value = -valMid;  % change the sign before return
        return;
    end
    if (extVol > externalVolumeDesired)
        valMin = valMid;
    else
        valMax = valMid;
    end
    iter = iter+1;
end